package com.fiec.DrConnect.models.dto;

import lombok.Data;

@Data
public class AuthRequestDto {
    String email;
    String password;
}

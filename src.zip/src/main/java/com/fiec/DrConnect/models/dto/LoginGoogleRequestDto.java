package com.fiec.DrConnect.models.dto;

import lombok.Data;

@Data
public class LoginGoogleRequestDto {
    private String tokenId;
}

package com.fiec.DrConnect.models.dto;

import lombok.Data;

@Data
public class LoginRequestDto {
    String email;
    String password;
}

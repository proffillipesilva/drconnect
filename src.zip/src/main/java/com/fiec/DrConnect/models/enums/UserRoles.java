package com.fiec.DrConnect.models.enums;

public enum UserRoles {
    ROLE_USER,
    ROLE_ADMIN
}
